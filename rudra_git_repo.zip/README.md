# Rudra Instruments Website

This is the static website for Rudra Instruments, created from the product catalog and hosted via GitHub Pages.